#!/usr/bin/env node

var fs = require("fs");
var data = fs.readFileSync("Ramblin' Wreck.midi",'binary');
//console.log(data);
var t = data;
var ff = [];
var mx = t.length;
var scc= String.fromCharCode;
for (var z = 0; z < mx; z++) {
	ff[z] = scc(t.charCodeAt(z) & 255);
//	if(z < 30) console.log(t.charCodeAt(z));
}
data = ff.join("");
//console.log(data);
eval(fs.readFileSync("jasmid/stream.js")+'');
eval(fs.readFileSync('jasmid/midifile.js')+'');
var song = MidiFile(data);
console.log(song.header);

for(var i = 0; i < song.tracks[1].length; i++){
	var o = song.tracks[1][i];
	if(o.type == "channel"){
		console.log('[' + o.noteNumber + ',' + o.deltaTime  + '],');
	}
}
